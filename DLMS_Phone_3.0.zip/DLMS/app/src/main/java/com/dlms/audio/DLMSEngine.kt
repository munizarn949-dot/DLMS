package com.dlms.audio

import kotlin.math.*

/** Pure-Kotlin realtime DSP so the project can be built on Android without NDK/CMake. */
class DLMSEngine(private val sampleRate: Float = 48000f) {
    companion object {
        val FREQS = doubleArrayOf(20.0,25.0,31.5,40.0,50.0,63.0,80.0,100.0,125.0,160.0,200.0,250.0,315.0,400.0,500.0,630.0,800.0,1000.0,1250.0,1600.0,2000.0,2500.0,3150.0,4000.0,5000.0,6300.0,8000.0,10000.0,12500.0,16000.0,20000.0)
    }

    private class Biquad {
        var b0=1f; var b1=0f; var b2=0f; var a1=0f; var a2=0f
        var z1=0f; var z2=0f
        fun process(x: Float): Float { val y=b0*x+z1; z1=b1*x-a1*y+z2; z2=b2*x-a2*y; return y }
        fun reset(){z1=0f;z2=0f}
    }

    private val eq = Array(2) { Array(FREQS.size) { Biquad() } }
    private val lp = Array(2) { Array(2) { Biquad() } }
    private val hp = Array(2) { Array(2) { Biquad() } }
    private val bandDb = FloatArray(FREQS.size)
    private var preampDb=0f
    private var limiterDb=-1f
    private var compressorAmount=.45f
    private var loudnessTargetDb=-14f
    private var crossoverHz=80f
    private var compEnv=0f
    private var loudEnv=0f
    private var limiterGain=1f

    init { reset() }
    private fun db(db: Float)=10.0.pow(db/20.0).toFloat()
    private fun clamp(x:Float,a:Float,b:Float)=max(a,min(b,x))

    private fun peak(q:Biquad,f:Double,g:Double,qv:Double=1.0){
        val A=10.0.pow(g/40.0); val w=2.0*PI*f/sampleRate; val c=cos(w); val s=sin(w); val alpha=s/(2.0*qv)
        val b0=1+alpha*A; val b1=-2*c; val b2=1-alpha*A; val a0=1+alpha/A; val a1=-2*c; val a2=1-alpha/A
        q.b0=(b0/a0).toFloat();q.b1=(b1/a0).toFloat();q.b2=(b2/a0).toFloat();q.a1=(a1/a0).toFloat();q.a2=(a2/a0).toFloat()
    }
    private fun low(q:Biquad,f:Double){
        val w=2*PI*f/sampleRate;val c=cos(w);val s=sin(w);val a=s/(2*sqrt(.5));val b0=(1-c)/2;val b1=1-c;val b2=b0;val a0=1+a;val a1=-2*c;val a2=1-a
        q.b0=(b0/a0).toFloat();q.b1=(b1/a0).toFloat();q.b2=(b2/a0).toFloat();q.a1=(a1/a0).toFloat();q.a2=(a2/a0).toFloat()
    }
    private fun high(q:Biquad,f:Double){
        val w=2*PI*f/sampleRate;val c=cos(w);val s=sin(w);val a=s/(2*sqrt(.5));val b0=(1+c)/2;val b1=-(1+c);val b2=b0;val a0=1+a;val a1=-2*c;val a2=1-a
        q.b0=(b0/a0).toFloat();q.b1=(b1/a0).toFloat();q.b2=(b2/a0).toFloat();q.a1=(a1/a0).toFloat();q.a2=(a2/a0).toFloat()
    }
    private fun refreshEq(){ for(ch in 0..1) for(i in FREQS.indices) peak(eq[ch][i],FREQS[i],bandDb[i].toDouble()) }
    private fun refreshXover(){ for(ch in 0..1) { low(lp[ch][0],crossoverHz.toDouble());low(lp[ch][1],crossoverHz.toDouble());high(hp[ch][0],crossoverHz.toDouble());high(hp[ch][1],crossoverHz.toDouble()) } }
    fun setBand(i:Int,v:Float){if(i in bandDb.indices){bandDb[i]=clamp(v,-12f,12f);refreshEq()}}
    fun setPreamp(v:Float){preampDb=clamp(v,-12f,12f)}
    fun setLimiter(v:Float){limiterDb=clamp(v,-12f,0f)}
    fun setCompressor(v:Float){compressorAmount=clamp(v,0f,1f)}
    fun setLoudnessTarget(v:Float){loudnessTargetDb=clamp(v,-24f,-8f)}
    fun setCrossover(v:Float){crossoverHz=clamp(v,40f,200f);refreshXover()}
    fun reset(){ java.util.Arrays.fill(bandDb,0f);preampDb=0f;limiterDb=-1f;compressorAmount=.45f;loudnessTargetDb=-14f;crossoverHz=80f;compEnv=0f;loudEnv=0f;limiterGain=1f;refreshEq();refreshXover();for(ch in 0..1){for(q in eq[ch])q.reset();for(q in lp[ch])q.reset();for(q in hp[ch])q.reset()} }

    fun process(buf:FloatArray, frames:Int = buf.size/2){
        val inGain=db(preampDb); val ceiling=db(limiterDb)
        val compAtk=exp(-1f/(.010f*sampleRate)); val compRel=exp(-1f/(.100f*sampleRate)); val loudAtk=exp(-1f/(.300f*sampleRate))
        val n=min(frames,buf.size/2)
        var i=0
        while(i<n){
            var l=buf[2*i]*inGain; var r=buf[2*i+1]*inGain
            for(b in FREQS.indices){l=eq[0][b].process(l);r=eq[1][b].process(r)}
            val mono=.5f*(l+r); val det=abs(mono); compEnv=if(det>compEnv) compAtk*compEnv+(1-compAtk)*det else compRel*compEnv+(1-compRel)*det
            val lev=20f*log10(max(compEnv,1e-6f)); val ratio=1f+19f*compressorAmount; val cg=if(lev>-18f) db(-18f+(lev+18f)/ratio-lev) else 1f; l*=cg;r*=cg
            val lm=.5f*(l+r); loudEnv=loudAtk*loudEnv+(1-loudAtk)*abs(lm); val ldb=20f*log10(max(loudEnv,1e-6f)); val lg=db(clamp((loudnessTargetDb-ldb)*.12f,-6f,6f));l*=lg;r*=lg
            // Real LR4 split/recombine stage. The recombined signal remains full-band.
            val loL=lp[0][1].process(lp[0][0].process(l)); val hiL=hp[0][1].process(hp[0][0].process(l)); l=loL+(l-loL-hiL)+hiL
            val loR=lp[1][1].process(lp[1][0].process(r)); val hiR=hp[1][1].process(hp[1][0].process(r)); r=loR+(r-loR-hiR)+hiR
            val p=max(abs(l),abs(r)); if(p>ceiling) limiterGain=min(limiterGain,ceiling/max(p,1e-9f)) else limiterGain += (1f-limiterGain)*.0002f
            l*=limiterGain;r*=limiterGain;buf[2*i]=clamp(l,-1f,1f);buf[2*i+1]=clamp(r,-1f,1f);i++
        }
    }
}
