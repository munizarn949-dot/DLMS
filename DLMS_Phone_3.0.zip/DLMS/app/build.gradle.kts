plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dlms.audio"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.dlms.audio"
        minSdk = 29
        targetSdk = 35
        versionCode = 3
        versionName = "3.0-phone"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
