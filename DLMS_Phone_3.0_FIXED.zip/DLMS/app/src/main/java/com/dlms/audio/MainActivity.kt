package com.dlms.audio

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.*
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val freqs = arrayOf("20","25","31.5","40","50","63","80","100","125","160","200","250","315","400","500","630","800","1k","1.25k","1.6k","2k","2.5k","3.15k","4k","5k","6.3k","8k","10k","12.5k","16k","20k")
    private val values = FloatArray(36)
    private lateinit var status: TextView
    private var projectionLauncher = 9001
    private var pendingStart = false

    override fun onCreate(b: Bundle?) { super.onCreate(b); values[32]=80f; values[33]=.45f; values[34]=-14f; values[35]=-1f; buildUi() }

    private fun buildUi(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,16,16,12);setBackgroundColor(Color.rgb(16,16,20))}
        root.addView(TextView(this).apply{text="DLMS  •  Digital Loudness Management System";textSize=20f;setTextColor(Color.WHITE);setPadding(0,0,0,4)})
        status=TextView(this).apply{text="Status: berhenti";textSize=13f;setTextColor(Color.LTGRAY);setPadding(0,0,0,10)};root.addView(status)
        val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val start=Button(this).apply{text="START AUDIO";setOnClickListener{requestAndStart()}}
        val stop=Button(this).apply{text="STOP";setOnClickListener{stopAudio()}}
        row.addView(start,LinearLayout.LayoutParams(0,52,1f));row.addView(stop,LinearLayout.LayoutParams(0,52,1f));root.addView(row)
        val preset=Spinner(this);preset.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Custom","Flat","Bass","Vocal","Rock","Headphone"));preset.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:android.widget.AdapterView<*>?){};override fun onItemSelected(p:android.widget.AdapterView<*>?,v:android.view.View?,pos:Int,id:Long){applyPreset(pos)}};root.addView(preset,LinearLayout.LayoutParams(-1,52))
        val scroll=HorizontalScrollView(this);val bands=LinearLayout(this).apply{gravity=Gravity.BOTTOM}
        freqs.forEachIndexed{i,f->
            val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL}
            val value=TextView(this).apply{text="0.0";textSize=11f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER}
            val seek=SeekBar(this).apply{max=240;progress=120;rotation=-90f;minimumHeight=170}
            seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,from:Boolean){val db=(p-120)/10f;value.text=String.format(Locale.US,"%.1f",db);values[i]=db;sendConfig()};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?) {}})
            col.addView(value,LinearLayout.LayoutParams(52,30));col.addView(seek,LinearLayout.LayoutParams(65,180));col.addView(TextView(this).apply{text=f;textSize=10f;setTextColor(Color.WHITE);gravity=Gravity.CENTER},LinearLayout.LayoutParams(52,40));bands.addView(col)
        };scroll.addView(bands);root.addView(scroll,LinearLayout.LayoutParams(-1,270))
        val controls=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        addControl(controls,"Preamp dB",-120,120,0){values[31]=it/10f;sendConfig()}
        addControl(controls,"Crossover Hz",400,2000,800){values[32]=it.toFloat();sendConfig()}
        addControl(controls,"Compressor %",0,100,45){values[33]=it/100f;sendConfig()}
        addControl(controls,"Loudness target dB",-240,-80,-140){values[34]=it/10f;sendConfig()}
        addControl(controls,"Limiter ceiling dB",-120,0,-10){values[35]=it/10f;sendConfig()}
        root.addView(controls)
        setContentView(root)
    }

    private fun addControl(parent:LinearLayout,label:String,min:Int,max:Int,start:Int,onChange:(Int)->Unit){val l=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};val t=TextView(this).apply{text="$label  ${start/10f}";setTextColor(Color.WHITE);textSize=12f};val s=SeekBar(this).apply{this.max=max-min;progress=start-min};s.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(v:SeekBar?,p:Int,from:Boolean){val x=p+min;t.text="$label  ${x/10f}";onChange(x)};override fun onStartTrackingTouch(v:SeekBar?){};override fun onStopTrackingTouch(v:SeekBar?) {}});l.addView(t,LinearLayout.LayoutParams(145,52));l.addView(s,LinearLayout.LayoutParams(0,52,1f));parent.addView(l)}

    private fun applyPreset(p:Int){
        val presets=when(p){1->FloatArray(31);2->floatArrayOf(6f,6f,5f,5f,4f,4f,3f,2f,2f,1f,1f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f);3->floatArrayOf(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1f,2f,3f,4f,4f,3f,2f,1f,0f,0f,0f,0f,0f,0f,0f);4->floatArrayOf(2f,2f,2f,2f,1f,1f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1f,2f,3f,3f,2f,2f,2f,1f,0f,0f,0f,0f,0f,0f,0f);5->floatArrayOf(0f,0f,1f,1f,1f,1f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1f,2f,3f,3f,2f,2f,1f,1f,1f,1f,0f,0f);else->FloatArray(31){0f}}
        for(i in presets.indices) values[i]=presets[i]; values[31]=0f; values[32]=80f; values[33]=.45f; values[34]=-14f; values[35]=-1f; sendConfig()
    }

    private fun sendConfig(){
        if (!::status.isInitialized) return
        val i=Intent(this,DLMSAudioService::class.java).setAction(DLMSAudioService.ACTION_CONFIG).putExtra(DLMSAudioService.EXTRA_CONFIG,values.copyOf())
        if(Build.VERSION.SDK_INT>=26) startService(i) else startService(i)
    }

    private fun requestAndStart(){
        if(Build.VERSION.SDK_INT<29){status.text="Android 10+ diperlukan untuk system playback capture";return}
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){pendingStart=true;requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),700);return}
        val pm=getSystemService(MediaProjectionManager::class.java);startActivityForResult(pm.createScreenCaptureIntent(),projectionLauncher)
    }
    private fun stopAudio(){stopService(Intent(this,DLMSAudioService::class.java));status.text="Status: berhenti"}
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==700&&grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED&&pendingStart){pendingStart=false;requestAndStart()}}
    @Suppress("DEPRECATION") override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==projectionLauncher&&resultCode==RESULT_OK&&data!=null){val i=Intent(this,DLMSAudioService::class.java).setAction(DLMSAudioService.ACTION_START).putExtra(DLMSAudioService.EXTRA_RESULT_CODE,resultCode).putExtra(DLMSAudioService.EXTRA_DATA,data).putExtra(DLMSAudioService.EXTRA_CONFIG,values.copyOf());if(Build.VERSION.SDK_INT>=26)startForegroundService(i) else startService(i);status.text="Status: aktif — capture → DSP → output"}else if(requestCode==projectionLauncher){status.text="Status: izin capture dibatalkan"}}
}
