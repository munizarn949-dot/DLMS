package com.dlms.audio

import android.app.*
import android.content.*
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.content.pm.ServiceInfo
import android.os.*
import java.util.concurrent.atomic.AtomicBoolean

class DLMSAudioService : Service() {
    companion object {
        const val ACTION_START = "com.dlms.audio.START"
        const val ACTION_STOP = "com.dlms.audio.STOP"
        const val ACTION_CONFIG = "com.dlms.audio.CONFIG"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_CONFIG = "config"
        const val ACTION_METRICS = "com.dlms.audio.METRICS"
        const val CHANNEL = "dlms_audio"
        const val NOTIFICATION_ID = 421
    }

    private val running = AtomicBoolean(false)
    private var thread: Thread? = null
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var engine: DLMSEngine? = null
    private var lastMetricsNs = 0L

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "DLMS Audio", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopPipeline(); stopSelf(); return START_NOT_STICKY }
            ACTION_CONFIG -> { applyConfig(intent.getFloatArrayExtra(EXTRA_CONFIG)); return START_STICKY }
            ACTION_START -> {
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
                if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
                startForeground(NOTIFICATION_ID, notification(), if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0)
                startPipeline(code, data, intent.getFloatArrayExtra(EXTRA_CONFIG))
            }
        }
        return START_STICKY
    }

    private fun notification(): Notification {
        val stop = PendingIntent.getService(this, 2, Intent(this, DLMSAudioService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL).setContentTitle("DLMS aktif").setContentText("Playback capture → DSP → output").setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).addAction(Notification.Action.Builder(null, "Stop", stop).build()).build()
    }

    private fun startPipeline(resultCode: Int, data: Intent, config: FloatArray?) {
        if (running.get()) return
        try {
            val pm = getSystemService(MediaProjectionManager::class.java)
            projection = pm.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopPipeline(); stopSelf() } }, Handler(Looper.getMainLooper()))
            val sampleRate = 48000
            val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
            require(min > 0) { "AudioRecord buffer tidak tersedia" }
            val size = maxOf(min, 4096 * 4)
            val capture = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            record = AudioRecord.Builder().setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()).setBufferSizeInBytes(size).setAudioPlaybackCaptureConfig(capture).build()
            require(record!!.state == AudioRecord.STATE_INITIALIZED) { "AudioRecord gagal diinisialisasi" }
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            track = AudioTrack.Builder().setAudioAttributes(attrs).setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()).setBufferSizeInBytes(size).setTransferMode(AudioTrack.MODE_STREAM).build()
            require(track!!.state == AudioTrack.STATE_INITIALIZED) { "AudioTrack gagal diinisialisasi" }
            engine = DLMSEngine()
            applyConfig(config)
            running.set(true)
            thread = Thread({ audioLoop() }, "DLMS-Audio")
            thread!!.priority = Thread.MAX_PRIORITY
            record!!.startRecording(); track!!.play(); thread!!.start()
        } catch (t: Throwable) {
            stopPipeline(); stopSelf()
        }
    }

    private fun applyConfig(c: FloatArray?) {
        val e = engine ?: return
        if (c == null || c.size < 21) return
        for (i in 0 until 16) e.setBand(i, c[i])
        e.setPreamp(c[16]); e.setCrossover(c[17]); e.setCompressor(c[18]); e.setLoudnessTarget(c[19]); e.setLimiter(c[20])
    }

    private fun audioLoop() {
        val buf = FloatArray(2048 * 2)
        while (running.get()) {
            val n = record?.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING) ?: -1
            if (n > 0) {
                engine?.process(buf, n / 2)
                track?.write(buf, 0, n, AudioTrack.WRITE_BLOCKING)
                val now = System.nanoTime()
                if (now - lastMetricsNs >= 100_000_000L) {
                    engine?.telemetry()?.let { m ->
                        sendBroadcast(Intent(ACTION_METRICS).setPackage(packageName)
                            .putExtra("inPeakL", m[0]).putExtra("inPeakR", m[1])
                            .putExtra("outPeakL", m[2]).putExtra("outPeakR", m[3])
                            .putExtra("inRms", m[4]).putExtra("outRms", m[5])
                            .putExtra("sub", m[6]).putExtra("low", m[7]).putExtra("mid", m[8]).putExtra("high", m[9])
                            .putExtra("loudness", m[10]).putExtra("peakDb", m[11]))
                    }
                    lastMetricsNs = now
                }
            } else if (n < 0) break
        }
    }

    private fun stopPipeline() {
        if (!running.getAndSet(false)) return
        try { record?.stop() } catch (_: Throwable) {}
        try { track?.pause(); track?.flush(); track?.stop() } catch (_: Throwable) {}
        try { thread?.join(300) } catch (_: Throwable) {}
        try { record?.release() } catch (_: Throwable) {}
        try { track?.release() } catch (_: Throwable) {}
        try { projection?.stop() } catch (_: Throwable) {}
        record = null; track = null; projection = null; thread = null; engine = null; lastMetricsNs = 0L
    }

    override fun onDestroy() { stopPipeline(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
