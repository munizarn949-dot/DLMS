package com.dlms.audio

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.Gravity
import android.widget.*
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val freqs = arrayOf("20", "31.5", "50", "80", "125", "200", "315", "500", "800", "1.25k", "2k", "3.15k", "5k", "8k", "12.5k", "20k")
    // 16-band console EQ + preamp + crossover + compressor + loudness + limiter
    private val values = FloatArray(21)
    private lateinit var status: TextView
    private lateinit var masterL: ProgressBar
    private lateinit var masterR: ProgressBar
    private lateinit var peakText: TextView
    private lateinit var rmsText: TextView
    private lateinit var loudText: TextView
    private lateinit var analyzerText: TextView
    private lateinit var dspText: TextView
    private var projectionLauncher = 9001
    private var pendingStart = false

    private val metricsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != DLMSAudioService.ACTION_METRICS) return
            val l = intent.getFloatExtra("outPeakL", 0f)
            val r = intent.getFloatExtra("outPeakR", 0f)
            val inRms = intent.getFloatExtra("inRms", 0f)
            val outRms = intent.getFloatExtra("outRms", 0f)
            val sub = intent.getFloatExtra("sub", 0f)
            val low = intent.getFloatExtra("low", 0f)
            val mid = intent.getFloatExtra("mid", 0f)
            val high = intent.getFloatExtra("high", 0f)
            val loud = intent.getFloatExtra("loudness", -60f)
            val peakDb = intent.getFloatExtra("peakDb", -60f)
            masterL.progress = meterPercent(l)
            masterR.progress = meterPercent(r)
            peakText.text = "PEAK  L ${db(l)} dBFS   R ${db(r)} dBFS"
            rmsText.text = "RMS   IN ${db(inRms)} dBFS   OUT ${db(outRms)} dBFS"
            loudText.text = "LOUDNESS EST.  ${formatDb(loud)} dB   •   PEAK ${formatDb(peakDb)} dBFS"
            analyzerText.text = "SUB ${formatDb(sub)}   |   LOW ${formatDb(low)}   |   MID ${formatDb(mid)}   |   HIGH ${formatDb(high)}"
            dspText.text = "LIVE DSP  •  capture → 16-band EQ → comp → loudness → crossover → limiter → output"
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        values[17] = 250f
        values[18] = .45f
        values[19] = -14f
        values[20] = -1f
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        val f = IntentFilter(DLMSAudioService.ACTION_METRICS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(metricsReceiver, f, RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(metricsReceiver, f)
    }

    override fun onPause() { try { unregisterReceiver(metricsReceiver) } catch (_: Throwable) {}; super.onPause() }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 24)
            setBackgroundColor(Color.rgb(9, 11, 15))
        }
        titleBlock(page)
        mixerBlock(page)
        analyzerBlock(page)
        effectsBlock(page)
        dlmsBlock(page)
        crossoverBlock(page)
        eq16Block(page)
        masterControlBlock(page)
        monitorBlock(page)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun titleBlock(root: LinearLayout) {
        val box = card()
        box.addView(tv("DLMS PRO", 25f, Color.WHITE))
        box.addView(tv("DIGITAL LOUDNESS MANAGEMENT • MATRIX PROCESSOR", 11f, Color.LTGRAY))
        status = tv("Status: berhenti", 12f, Color.LTGRAY)
        box.addView(status)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val start = Button(this).apply { text = "START AUDIO"; setOnClickListener { requestAndStart() } }
        val stop = Button(this).apply { text = "STOP"; setOnClickListener { stopAudio() } }
        row.addView(start, LinearLayout.LayoutParams(0, 52, 1f)); row.addView(stop, LinearLayout.LayoutParams(0, 52, 1f))
        box.addView(row); root.addView(box)
    }

    private fun mixerBlock(root: LinearLayout) {
        val box = card(); sectionTitle(box, "MASTER MIXER / INPUT MATRIX")
        val labels = arrayOf("CH1 L", "CH2 R", "MIC / AUX", "MASTER")
        val cols = LinearLayout(this).apply { gravity = Gravity.CENTER }
        labels.forEach { name ->
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            c.addView(tv(name, 10f, Color.WHITE).apply { gravity = Gravity.CENTER })
            c.addView(TextView(this).apply { text = "●"; textSize = 28f; setTextColor(Color.rgb(80, 210, 150)); gravity = Gravity.CENTER; setPadding(0, 4, 0, 4) })
            c.addView(tv("0.0 dB", 9f, Color.LTGRAY).apply { gravity = Gravity.CENTER })
            cols.addView(c, LinearLayout.LayoutParams(0, 90, 1f))
        }
        box.addView(cols)
        addDecimalControl(box, "Master Preamp dB", -120, 120, 0) { values[16] = it / 10f; sendConfig() }
        root.addView(box)
    }

    private fun analyzerBlock(root: LinearLayout) {
        val box = card(); sectionTitle(box, "FREQ ANALYZER • REAL-TIME ENERGY")
        analyzerText = tv("SUB --   |   LOW --   |   MID --   |   HIGH --", 12f, Color.WHITE); box.addView(analyzerText)
        box.addView(tv("L / R playback analyzer • data berasal dari audio capture yang sedang diproses", 9f, Color.LTGRAY))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        arrayOf("SUB\n20–80", "LOW\n80–250", "MID\n250–1.2k", "HIGH\n1.2k+").forEach { x ->
            row.addView(tv(x, 10f, Color.WHITE).apply { gravity = Gravity.CENTER; setPadding(2, 16, 2, 16) }, LinearLayout.LayoutParams(0, 65, 1f))
        }
        box.addView(row); root.addView(box)
    }

    private fun effectsBlock(root: LinearLayout) {
        val box = card(); sectionTitle(box, "EFFECTS MATRIX")
        arrayOf("INPUT", "MIX", "DECAY", "DELAY", "OUTPUT").forEach { addDecimalControl(box, it, 0, 1000, 0) { } }
        val bypass = CheckBox(this).apply { text = "BYPASS EFFECT"; setTextColor(Color.WHITE) }
        box.addView(bypass); root.addView(box)
    }

    private fun dlmsBlock(root: LinearLayout) {
        val box = card(); sectionTitle(box, "DLMS DIGITAL LOUDSPEAKER MANAGEMENT")
        box.addView(tv("MATRIX PROCESSOR • LIVE TELEMETRY", 10f, Color.LTGRAY))
        masterL = meter(); masterR = meter(); masterL.progress = 0; masterR.progress = 0
        box.addView(tv("CHANNEL L", 9f, Color.WHITE)); box.addView(masterL)
        box.addView(tv("CHANNEL R", 9f, Color.WHITE)); box.addView(masterR)
        peakText = tv("PEAK  L -- dBFS   R -- dBFS", 11f, Color.WHITE); box.addView(peakText)
        rmsText = tv("RMS   IN -- dBFS   OUT -- dBFS", 11f, Color.LTGRAY); box.addView(rmsText)
        root.addView(box)
    }

    private fun crossoverBlock(root: LinearLayout) {
        val box = card(); sectionTitle(box, "STEREO 3-WAY ACTIVE CROSSOVER")
        addHzControl(box, "LOW / MID crossover", 40, 2000, 250) { values[17] = it.toFloat(); sendConfig() }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        arrayOf("LOW", "MID", "HIGH").forEach { band -> row.addView(tv("$band\nACTIVE", 11f, Color.WHITE).apply { gravity = Gravity.CENTER; setPadding(8, 14, 8, 14) }, LinearLayout.LayoutParams(0, 65, 1f)) }
        box.addView(row); root.addView(box)
    }

    private fun eq16Block(root: LinearLayout) {
        val box = card(); sectionTitle(box, "DUAL 16-BAND GRAPHIC EQUALIZER")
        box.addView(tv("CH1 L / CH2 R • 16-band control • ±12 dB", 10f, Color.LTGRAY))
        val hs = HorizontalScrollView(this)
        val bands = LinearLayout(this).apply { gravity = Gravity.BOTTOM }
        freqs.forEachIndexed { i, f ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            val value = tv("0.0", 9f, Color.WHITE).apply { gravity = Gravity.CENTER }
            val seek = SeekBar(this).apply { max = 240; progress = 120; rotation = -90f; minimumHeight = 150 }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, from: Boolean) {
                    val d = (p - 120) / 10f
                    value.text = String.format(Locale.US, "%.1f", d)
                    values[i] = d
                    sendConfig()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(value, LinearLayout.LayoutParams(48, 26)); col.addView(seek, LinearLayout.LayoutParams(58, 160)); col.addView(tv(f, 9f, Color.LTGRAY).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(48, 34)); bands.addView(col)
        }
        hs.addView(bands); box.addView(hs, LinearLayout.LayoutParams(-1, 230)); root.addView(box)
    }

    private fun masterControlBlock(root: LinearLayout) {
        val box = card(); sectionTitle(box, "COMPRESSOR • LOUDNESS • LIMITER")
        addPercentControl(box, "Compressor", 0, 100, 45) { values[18] = it / 100f; sendConfig() }
        addDecimalControl(box, "Loudness target dB", -240, -80, -140) { values[19] = it / 10f; sendConfig() }
        addDecimalControl(box, "Limiter ceiling dB", -120, 0, -10) { values[20] = it / 10f; sendConfig() }
        root.addView(box)
    }

    private fun monitorBlock(root: LinearLayout) {
        val box = card(); sectionTitle(box, "SYSTEM MONITOR / DATA")
        loudText = tv("LOUDNESS EST. -- dB • PEAK -- dBFS", 12f, Color.WHITE); box.addView(loudText)
        dspText = tv("DSP idle", 10f, Color.LTGRAY); box.addView(dspText)
        box.addView(tv("48 kHz • Stereo • PCM Float • Playback Capture", 10f, Color.LTGRAY))
        root.addView(box)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 14); setBackgroundColor(Color.rgb(22, 25, 32)); val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, 12); layoutParams = lp }
    private fun sectionTitle(parent: LinearLayout, text: String) { parent.addView(tv(text, 15f, Color.WHITE).apply { setPadding(0, 0, 0, 8) }) }
    private fun tv(text: String, size: Float, color: Int) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }
    private fun meter() = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; progress = 0 }

    private fun addDecimalControl(parent: LinearLayout, label: String, min: Int, max: Int, start: Int, onChange: (Int) -> Unit) {
        val l = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val t = tv("$label  ${start / 10f}", 11f, Color.WHITE)
        val s = SeekBar(this).apply { this.max = max - min; progress = start - min }
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(v: SeekBar?, p: Int, from: Boolean) { val x = p + min; t.text = "$label  ${x / 10f}"; onChange(x) }
            override fun onStartTrackingTouch(v: SeekBar?) {}
            override fun onStopTrackingTouch(v: SeekBar?) {}
        })
        l.addView(t, LinearLayout.LayoutParams(165, 48)); l.addView(s, LinearLayout.LayoutParams(0, 48, 1f)); parent.addView(l)
    }

    private fun addHzControl(parent: LinearLayout, label: String, min: Int, max: Int, start: Int, onChange: (Int) -> Unit) {
        val l = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val t = tv("$label  ${start} Hz", 11f, Color.WHITE)
        val s = SeekBar(this).apply { this.max = max - min; progress = start - min }
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(v: SeekBar?, p: Int, from: Boolean) { val x = p + min; t.text = "$label  ${x} Hz"; onChange(x) }
            override fun onStartTrackingTouch(v: SeekBar?) {}
            override fun onStopTrackingTouch(v: SeekBar?) {}
        })
        l.addView(t, LinearLayout.LayoutParams(165, 48)); l.addView(s, LinearLayout.LayoutParams(0, 48, 1f)); parent.addView(l)
    }

    private fun addPercentControl(parent: LinearLayout, label: String, min: Int, max: Int, start: Int, onChange: (Int) -> Unit) {
        val l = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val t = tv("$label  $start%", 11f, Color.WHITE)
        val s = SeekBar(this).apply { this.max = max - min; progress = start - min }
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(v: SeekBar?, p: Int, from: Boolean) { val x = p + min; t.text = "$label  $x%"; onChange(x) }
            override fun onStartTrackingTouch(v: SeekBar?) {}
            override fun onStopTrackingTouch(v: SeekBar?) {}
        })
        l.addView(t, LinearLayout.LayoutParams(165, 48)); l.addView(s, LinearLayout.LayoutParams(0, 48, 1f)); parent.addView(l)
    }

    private fun sendConfig() {
        if (!::status.isInitialized) return
        val i = Intent(this, DLMSAudioService::class.java).setAction(DLMSAudioService.ACTION_CONFIG).putExtra(DLMSAudioService.EXTRA_CONFIG, values.copyOf())
        startService(i)
    }

    private fun requestAndStart() {
        if (Build.VERSION.SDK_INT < 29) { status.text = "Android 10+ diperlukan untuk playback capture"; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { pendingStart = true; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 700); return }
        val pm = getSystemService(MediaProjectionManager::class.java); startActivityForResult(pm.createScreenCaptureIntent(), projectionLauncher)
    }

    private fun stopAudio() { stopService(Intent(this, DLMSAudioService::class.java)); status.text = "Status: berhenti"; dspText.text = "DSP idle" }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == 700 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && pendingStart) { pendingStart = false; requestAndStart() } }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionLauncher && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, DLMSAudioService::class.java).setAction(DLMSAudioService.ACTION_START).putExtra(DLMSAudioService.EXTRA_RESULT_CODE, resultCode).putExtra(DLMSAudioService.EXTRA_DATA, data).putExtra(DLMSAudioService.EXTRA_CONFIG, values.copyOf())
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            status.text = "Status: aktif — capture → DSP → output"
        } else if (requestCode == projectionLauncher) status.text = "Status: izin capture dibatalkan"
    }

    private fun meterPercent(v: Float): Int = (v.coerceIn(0f, 1f) * 1000f).roundToInt()
    private fun db(v: Float): String = formatDb(20f * kotlin.math.log10(v.coerceAtLeast(1e-6f)))
    private fun formatDb(v: Float): String = String.format(Locale.US, "%+.1f", v)
}
