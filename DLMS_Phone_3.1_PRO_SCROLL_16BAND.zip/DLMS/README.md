# DLMS Android — Phone Build Edition 3.0

Versi ini dibuat khusus agar bisa dibuild **langsung dari HP Android**, tanpa Android NDK/CMake. DSP dipindahkan ke Kotlin murni.

## Yang aktif
- 16-band EQ: 20 Hz–20 kHz, ±12 dB
- Preamp
- Compressor
- Loudness target / auto gain
- Limiter stereo-linked
- LR4 crossover split/recombine stage
- Preset Flat / Bass / Vocal / Rock / Headphone
- AudioPlaybackCapture Android 10+
- AudioRecord float stereo 48 kHz
- DSP realtime di foreground service
- AudioTrack float stereo output
- Perubahan slider/preset dikirim live ke service

## Build langsung dari HP

Project ini tidak memakai NDK. AndroidIDE dapat membangun project Gradle di perangkat Android; AndroidIDE sendiri menyediakan JDK 11/17 dan Gradle support. Versi asli AndroidIDE sudah diarsipkan, jadi gunakan build/fork yang masih dapat dipasang dari sumber tepercaya.

1. Install AndroidIDE/AndroidIDE-Fix di HP.
2. Ekstrak `DLMS_Phone_3.0.zip`.
3. Di AndroidIDE pilih **Open existing project**.
4. Pilih folder `DLMS`.
5. Tunggu Gradle Sync.
6. Pastikan SDK Platform 35 tersedia.
7. Tekan **Run** atau **Build APK**.
8. Install APK hasil build.

## Menjalankan

1. Buka DLMS.
2. Tekan START AUDIO.
3. Izinkan microphone/audio capture.
4. Izinkan MediaProjection ketika dialog Android muncul.
5. Putar media/game yang mengizinkan playback capture.
6. Atur preset atau 31 band EQ.
7. Slider dapat diubah saat processing aktif.

## Batasan penting Android

`AudioPlaybackCapture` adalah mekanisme capture/tap, bukan API untuk mengganti/mematikan audio asli aplikasi sumber. Karena itu aplikasi biasa tidak dapat menjamin efek EQ benar-benar menggantikan audio asli secara system-wide pada semua perangkat. Aplikasi sumber juga dapat melarang playback capture.

Jika audio asli dan salinan hasil DSP terdengar bersamaan, itu adalah keterbatasan arsitektur Android public API, bukan kerusakan EQ. Untuk EQ yang benar-benar berada di jalur output sistem diperlukan integrasi audio tingkat sistem/OEM/root atau mekanisme audio-effect yang memang dipasang pada output device.

## Catatan performa

DSP Kotlin dibuat tanpa alokasi buffer pada loop audio. Namun kualitas realtime tetap tergantung CPU/ROM perangkat. Jika terjadi patah-patah, gunakan buffer audio yang lebih besar atau matikan compressor/loudness terlebih dahulu.


### UI/DSP note
The DLMS PRO scroll console uses a 16-band graphic EQ. The previous 31-band master EQ has been removed because it did not match the intended DLMS workflow.
